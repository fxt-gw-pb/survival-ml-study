---
name: survival-ml-shap
description: "Generate and audit SHAP explanations for fitted survival models using fastshap, shapviz, and model-specific prediction wrappers. Use when creating force, beeswarm, importance-bar, waterfall, or partial-dependence SHAP plots from the Xiaopang survival ML v3 workflow."
---

# Survival ML SHAP

Explain model predictions on a declared dataset and prediction scale.

## Procedure

1. Require fitted model objects, the training-fitted preprocessing recipe, and a clean feature matrix.
2. Run `scripts/check_shap_inputs.R MODEL_RDATA FEATURE.csv` before explanation.
3. Define and test one prediction wrapper per learner. Confirm output length, finiteness, and risk direction.
4. Set and report the SHAP background dataset, explained dataset, simulation count, seed, and prediction scale.
5. Generate global importance and beeswarm plots; generate force/waterfall plots only for clearly identified rows.
6. Label dependence plots as associations in the fitted model, not causal effects.
7. Save SHAP matrices separately from model objects with package versions.

## Code

- Read `references/code-map.md` for all eight wrappers and legacy plot calls.
- Adapt `assets/legacy-section.R`, containing the original `fastshap`/`shapviz` block.
