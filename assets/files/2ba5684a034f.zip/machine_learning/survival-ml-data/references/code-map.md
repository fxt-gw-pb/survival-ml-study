# Code map

`assets/legacy-section.R` corresponds to original lines 48-129.

| Original block | Adaptation |
| --- | --- |
| `read.csv("data.csv", encoding="GBK")` | Accept an explicit path and detect encoding. |
| Factor conversions | Replace with mappings from the project data dictionary. |
| `createDataPartition(..., p=0.7)` | Record seed, fraction, row IDs, and validation role. |
| `write.csv(traindata/testdata)` | Write to a dedicated run directory. |
| Cox/nomogram lead-in | Route to `$survival-ml-select`; do not combine with data preparation. |

The bundled example contains 65 records with `Time=0`; resolve these from the data-generating definition rather than silently changing them.
