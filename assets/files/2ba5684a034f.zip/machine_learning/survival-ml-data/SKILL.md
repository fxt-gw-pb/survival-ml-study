---
name: survival-ml-data
description: "Audit, clean, encode, and split censored Time/Event datasets for survival machine learning. Use when checking survival CSV structure, zero or missing follow-up, event coding, predictor types, leakage, train/test splitting, or preparing the data objects required by the Xiaopang survival ML v3 workflow."
---

# Survival ML Data

Prepare survival data before any feature selection or modeling.

## Procedure

1. Require numeric `Time > 0` and binary `Event` (`1=event`, `0=censored`).
2. Require a data dictionary before factor conversion. Do not reuse oncology labels unless codes match exactly.
3. Remove identifiers and post-outcome leakage variables from predictors.
4. Fit imputation and encoding on training data only.
5. Stratify a random split by `Event` only when no prespecified validation cohort exists.
6. Save `traindata.csv`, `testdata.csv`, the split seed, row identifiers, preprocessing recipe, and audit report.
7. Hand off to `$survival-ml-select` or `$survival-ml-train`.

## Code

- Run `scripts/audit_split.R INPUT.csv OUTPUT_DIR [train_fraction] [seed]`.
- Read `references/code-map.md` before adapting the source.
- Use `assets/legacy-section.R` only as provenance; it contains the original factor conversion, split, Cox screening, and nomogram lead-in.

Stop if follow-up units, event definition, factor codes, or validation role are unclear.
