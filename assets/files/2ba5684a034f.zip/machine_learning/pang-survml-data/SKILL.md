---
name: pang-survml-data
description: Validate, encode and split right-censored survival data using the source’s Time/Event contract while preventing leakage. Use for CSV intake, variable dictionaries, factor mappings, zero-time resolution, development/validation partitioning or preprocessing recipes.
---

# Data preparation

Read `references/source-data-map.md`. Require the user to confirm outcome definition, time unit, index date, censoring, ID, predictor windows and zero-time policy. Run `scripts/prepare_split.R <input.csv> <output_dir> [seed] [train_fraction] [zero_policy]`.

Accept `zero_policy` only as `error`, `exclude`, or `epsilon:<positive value>` after user justification. Preserve raw data and write exclusions/split membership. Fit all transformations on development data. Do not use the legacy output CSV factor labels as inputs to models that were trained on numeric codes.
