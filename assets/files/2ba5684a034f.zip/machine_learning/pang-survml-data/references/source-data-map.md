# Source data mapping

Main-script lines 52-84 read `data.csv`, encode 16 predictors and create a 70/30 event-stratified split with seed 123. The original 2,038 rows yield 1,427 development and 611 test rows. There are 1,224 events, 814 censored observations and 65 records with `Time=0`.

Legacy factor labels include a typo (`GreadI`–`GreadIV`) and mixed meanings (`No/Unknown`). Preserve raw codes plus a versioned dictionary rather than relying on labels. The original train/test CSVs contain factor labels, whereas later modeling rereads numeric `data.csv`; this representation mismatch must remain visible.
