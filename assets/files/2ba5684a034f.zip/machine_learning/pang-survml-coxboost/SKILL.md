---
name: pang-survml-coxboost
description: Install, tune, train and predict CoxBoost corresponding to main-script lines 295-305 and the bundled CoxBoost source package. Use for component-wise likelihood boosting, penalty optimization, step selection and CoxBoost SHAP wrappers.
---

# CoxBoost

Verify the environment with `$pang-survml-environment`, then run `scripts/train_coxboost.R <development.csv> <validation.csv> <output_dir> [predictors_csv] [seed]`. Optimize the penalty and step count only in development data. Save both tuning results and the fitted object. Use matrix columns in identical order for validation.
