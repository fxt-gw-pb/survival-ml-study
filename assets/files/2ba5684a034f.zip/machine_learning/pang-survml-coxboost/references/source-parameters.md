# Source parameters

The source starts penalty optimization at 200, tunes up to 200 steps with three-fold Verweij CV, and predicts `type='lp'`. The folder bundles a historical CoxBoost package source with R/C implementation and manuals. Use more stable fold counts when event numbers permit, record package provenance and never pass outcome values from validation merely to obtain a linear predictor.
