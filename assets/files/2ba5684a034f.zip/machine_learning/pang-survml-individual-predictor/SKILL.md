---
name: pang-survml-individual-predictor
description: Reconstruct and audit the PLS-R Cox Shiny individual survival predictor saved only inside Survival_ML_model_SHAP.RData. Use for an offline research prototype that accepts the eight legacy predictors and displays 1–5 year survival probabilities and a curve.
---

# Individual predictor

Read `references/rdata-app.md`. Run `scripts/build_app.R <model_payload.rds> <output_dir>` only after absolute-risk calibration and predictor coding are validated. Keep the app clearly labeled “research use only”; validate factor/code mapping, out-of-range values, missing inputs, baseline survival, model version and data provenance. Do not deploy or provide treatment advice without clinical governance.
