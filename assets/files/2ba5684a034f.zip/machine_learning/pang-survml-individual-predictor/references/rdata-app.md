# RData-only application

The 119-object SHAP workspace contains `ui` and `server` absent from the 1,283-line script. The app title is “PLS-R Cox Survival Prediction”. Inputs are Age, Race, Grade, Surgery, Chemotherapy, Marital, SEER_stage and Tumor_size using legacy numeric codes. It predicts a plsRcox risk and raises a saved baseline survival to that risk at 12–60 months. This transformation requires independent verification; the saved app has no model/version banner, input validation or deployment safeguards.
