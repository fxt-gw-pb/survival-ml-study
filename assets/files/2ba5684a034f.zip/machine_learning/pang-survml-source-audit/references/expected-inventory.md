# Expected inventory

Audited source snapshot: 121 files in 12 subdirectories, 155,936,268 bytes.

- 77 PDF files, all one page.
- 7 R files: the 1,283-line main script, CoxBoost installer and five CoxBoost package R sources.
- 6 CSV files: source data, labeled train/test partitions, Cox table and numeric train/test prediction tables.
- 2 RData workspaces: 62 and 119 objects respectively.
- 15 CoxBoost Rd manuals, 2 C sources, one CoxBoost ZIP, one `distr6` tarball and package metadata.

Known discrepancies: instructions say eight models; artifacts include Lasso-Cox plus eight current model labels. The main script emits CoxPH but older PDFs/RData use Lasso-Cox. The SHAP RData includes a PLS-R Cox Shiny app absent from the main script. Training ROC includes a 24-month file although the current loop names 12/36/60 months.
