---
name: pang-survml-source-audit
description: Create a no-omission inventory and source-to-skill mapping for the “小庞统计——生存机器学习预测3.0版本” folder. Use when verifying coverage of scripts, CSVs, RData objects, PDFs, package source, legacy outputs or version discrepancies.
---

# Source audit

Run `scripts/inventory_source.R <source_dir> <output_dir>`. Inspect every file category, not only the main R script. For PDFs, render every page or verify page count and visually inspect category contact sheets. For RData, load into a new environment and list names/classes/sizes without attaching it to `.GlobalEnv`.

Compare the inventory with `references/expected-inventory.md`. Flag missing, extra, empty, unreadable and internally inconsistent artifacts. Emit a file-level manifest and an issue register; never infer that differently named artifacts belong to the same execution.
