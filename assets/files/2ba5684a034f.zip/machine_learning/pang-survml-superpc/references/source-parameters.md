# Source parameters

The source uses `s0.perc=.5`, 20 thresholds, ten folds, up to three components, minimum five features and selects the maximum score in the first component row. Preserve the threshold and training data structure because `superpc.predict` requires both.
