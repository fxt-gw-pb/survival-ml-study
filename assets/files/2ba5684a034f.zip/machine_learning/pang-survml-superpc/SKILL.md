---
name: pang-survml-superpc
description: Train, cross-validate and predict supervised principal components for survival corresponding to main-script lines 348-365. Use for SuperPC threshold/component selection, locked risk scores and SuperPC SHAP wrappers.
---

# SuperPC survival model

Run `scripts/train_superpc.R <development.csv> <validation.csv> <output_dir> [predictors_csv] [seed]`. Keep the transposed feature-by-sample layout, feature names and selected threshold together. Choose threshold/components using development CV and never recompute them in validation.
