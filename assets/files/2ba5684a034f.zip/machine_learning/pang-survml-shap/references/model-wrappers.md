# Model wrappers and source outputs

The source defines wrappers for RSF mortality, GBM link score, CoxPH risk, CoxBoost linear predictor, Survival-SVM score, SuperPC score and plsRcox risk; XGBoost uses native `shapviz`. It generates force, beeswarm and bar plots for multiple legacy models plus one Survival-SVM waterfall and a 16-panel dependence page. Existing PDFs show CoxBoost, GBM, Lasso-Cox, RSF, SuperPC, Survival-SVM and XGBoost; the current script computes CoxPH/plsRcox SHAP but does not save their plots. Preserve this output mismatch in the manifest.
