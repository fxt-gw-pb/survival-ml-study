---
name: pang-survml-shap
description: Generate model-specific SHAP explanations corresponding to main-script lines 406-653 and all 23 SHAP PDFs. Use for global importance, beeswarm, force, waterfall or feature-dependence plots for RSF, GBM, CoxPH/Lasso-Cox, CoxBoost, Survival-SVM, XGBoost, SuperPC or plsRcox.
---

# Survival-model SHAP

Read `references/model-wrappers.md`, then run `scripts/explain_score.R <model.rds> <background.csv> <output_dir> <model_type> [nsim]`. State the explained target in every title. The default target is the model risk/linear-predictor score, not survival probability. Use a prespecified horizon-risk wrapper when clinical absolute risk is the target.

Use development/background data that represent the intended population. Fix the seed, record Monte Carlo simulations, and verify prediction invariance before explanation. Generate global bar/beeswarm and declared individual force/waterfall plots; do not cherry-pick individuals.
