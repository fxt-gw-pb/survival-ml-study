# Code map

`assets/legacy-section.R` corresponds to original lines 818-991.

- 818-900: calibration helper and model loops.
- 901-945: training DCA at 12/36/60.
- 947-991: validation DCA.

Verify that each input is a horizon-specific event probability. A raw ranking score is not automatically valid for calibration or DCA. Use identical horizons and the frozen training model in validation.
