---
name: survival-ml-calibration-dca
description: "Assess survival prediction calibration and decision-curve clinical utility at prespecified horizons. Use when adapting calibration plots, dcurves/ggDCA analyses, or train/test clinical-utility evaluation from the Xiaopang survival ML v3 workflow."
---

# Survival ML Calibration and DCA

Evaluate absolute risk accuracy and net benefit at justified horizons.

## Procedure

1. Require survival outcomes, risk scores or survival probabilities, dataset role, and horizon.
2. Run `scripts/check_prediction_table.R PREDICTIONS.csv`.
3. Convert risk scores to horizon-specific probabilities using training-fitted models; do not treat arbitrary scores as probabilities.
4. Plot observed versus predicted risk with uncertainty; report calibration intercept/slope when feasible.
5. Run DCA only across plausible clinical thresholds and include treat-all/treat-none strategies.
6. Keep the validation cohort untouched and use identical models/horizons.
7. Export underlying calibration and net-benefit tables.

## Code

- Read `references/code-map.md` for the legacy calibration function and 12/36/60-month DCA loops.
- Adapt `assets/legacy-section.R`; verify time units before execution.
