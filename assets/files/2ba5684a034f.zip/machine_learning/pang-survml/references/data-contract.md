# Data contract

Require one row per analysis unit unless a declared landmark or start-stop design is used.

- `Time`: numeric duration from a declared time origin to event/censoring; record the unit.
- `Event`: integer `1=event`, `0=censored`; route competing events to a declared competing-risk workflow.
- Stable patient/episode ID: require it for duplicate detection, grouped splitting and traceability even though the legacy file lacks one.
- Predictors: document definitions, units, collection window, permissible values, missing-value codes and availability at prediction time.

Before modeling, verify time values, event coding, duplicate IDs, impossible values, missingness, sparse factor levels, train/test factor compatibility, post-index leakage and event counts.

Do not silently replace `Time <= 0` with `0.003`. The source data contain 65 zero-time records. Obtain a defensible policy: correct source errors, define a minimum measurable interval with sensitivity analysis, use a same-day convention, or exclude with a flow count.

Fit imputation, scaling, dummy-variable levels, feature selection and tuning only on development folds. Apply the locked recipe to validation data. Store split membership by ID.
