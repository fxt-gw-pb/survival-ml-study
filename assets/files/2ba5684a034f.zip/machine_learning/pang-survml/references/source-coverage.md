# Source coverage and module routing

The source root contains 121 files: 1,283 lines in the main R script, 6 CSV files, 2 RData workspaces, 77 one-page PDFs, a complete CoxBoost source tree/archive, instructions and package artifacts.

| Source component | Exact source | Authoritative module |
|---|---|---|
| Packages, hard-coded working directory | main R lines 12-49; `包的安装/` | `pang-survml-environment` |
| CSV contract, factor labels, 70/30 split | lines 50-87; `data.csv`, `traindata.csv`, `testdata.csv` | `pang-survml-data` |
| Univariable/multivariable Cox | lines 88-105; Cox result CSV | `pang-survml-cox-screen` |
| Nomogram and risk score | lines 106-128; `Nomogram.pdf`; RData `nom1/res.cox/Nomo_*` | `pang-survml-nomogram` |
| LASSO paths and selection | lines 129-257; two LASSO PDFs; RData `fit/cvfit/rid` | `pang-survml-lasso` |
| RSF | lines 260-272 | `pang-survml-rsf` |
| GBM | lines 274-283 | `pang-survml-gbm` |
| CoxPH | lines 288-291 | `pang-survml-coxph` |
| Legacy Lasso-Cox model | PDFs and `Survival_ML_model.RData`; absent from current main model block | `pang-survml-lasso-cox` |
| CoxBoost | lines 295-305 and bundled package source | `pang-survml-coxboost` |
| Survival-SVM | lines 311-322 | `pang-survml-survivalsvm` |
| XGBoost Cox | lines 327-345 | `pang-survml-xgboost` |
| SuperPC | lines 348-365 | `pang-survml-superpc` |
| plsRcox | lines 368-373 | `pang-survml-plsrcox` |
| Prediction tables | lines 381-401; `*_plot_data.csv` | `pang-survml-predictions` |
| Model-specific SHAP wrappers and plots | lines 406-653; 23 SHAP PDFs; RData SHAP objects | `pang-survml-shap` |
| Time-dependent AUC | lines 655-747; four AUC/C-index PDFs | `pang-survml-time-auc` |
| Time-dependent C-index | lines 751-814 | `pang-survml-cindex` |
| Calibration | lines 818-895; 18 PDFs | `pang-survml-calibration` |
| DCA | lines 898-986; six PDFs | `pang-survml-dca` |
| Horizon ROC | lines 988-1190; seven PDFs | `pang-survml-roc` |
| KM risk groups | lines 1193-1283; 16 PDFs | `pang-survml-km` |
| PLS-R Cox Shiny predictor | only saved as RData `ui/server`, not in current script | `pang-survml-individual-predictor` |
| Saved environments and output consistency | two RData files and all 77 PDFs | `pang-survml-artifact-audit` |

The PDF set exposes nine model labels (`Coxph`, `Lasso_Cox`, `CoxBoost`, `RSF`, `GBM`, `Survivalsvm`, `xgboost`, `superpc`, `plsRcox`) although the text instruction says eight and the current training block uses CoxPH instead of Lasso-Cox. Preserve this as a version discrepancy; never pretend the artifacts came from one internally consistent run.
