# Methodological corrections to the legacy workflow

Use corrected defaults for new work; preserve legacy behavior only under an explicitly labeled reproduction mode.

1. Replace hard-coded `setwd()` with arguments and project-relative paths.
2. Resolve zero follow-up times explicitly; never silently recode them.
3. Keep one preprocessing recipe. The source writes labeled factors and later rereads numeric codes, creating incompatible representations.
4. Tune inside resampling. XGBoost must not use training data as its own early-stopping validation set; `plsRcox` must use its selected component count.
5. Keep algorithm objects separate from Cox surrogate models; the source overwrites names such as `RSF` and `GBM`.
6. Use IPCW time-to-event ROC/AUC. The source pROC conversion treats subjects censored before a horizon as controls.
7. Validate fixed predictions. Do not refit a Cox mapping on an external test cohort for calibration or DCA.
8. Derive risk cutoffs in development data and apply them unchanged to validation.
9. Express nomogram horizons in the same unit as `Time`; with months use `12,36,60`, not `1,3,5`.
10. Label SHAP targets precisely: linear predictor, mortality, or horizon-specific risk.
11. Report uncertainty and optimism correction, assess proportional hazards and calibration slope/intercept, and distinguish apparent/internal/external validation.
12. Save named objects and manifests with `saveRDS()` instead of entire global workspaces with `save.image()`.
