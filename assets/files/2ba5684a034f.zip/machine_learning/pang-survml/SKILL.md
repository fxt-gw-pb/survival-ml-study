---
name: pang-survml
description: End-to-end controller reconstructed from “小庞统计——生存机器学习预测3.0版本”. Use when Codex must audit data, reproduce or improve the complete survival-machine-learning workflow, route work to the exact model/evaluation module, or deliver a traceable analysis package with Cox screening, nomogram, LASSO, nine model families, SHAP, AUC, C-index, ROC, calibration, DCA, KM and individual prediction.
---

# Pang Survival ML Controller

Treat this suite as a reproducible research workflow, not as a single monolithic R script.

## Required first actions

1. Read `references/source-coverage.md` to identify every source component and its module.
2. Read `references/data-contract.md` before opening or modeling user data.
3. Run `scripts/preflight.R <data.csv> <output_dir>`.
4. Stop before modeling if event coding, time unit, index date, censoring rule, patient ID, duplicated observations, or zero follow-up policy is unresolved.
5. Create an immutable analysis configuration recording seed, split or validation design, horizons, predictors, exclusions, missing-data policy and package versions.

## Route modules

- Environment and CoxBoost source package: `$pang-survml-environment`
- Full source/artifact inventory: `$pang-survml-source-audit`
- Data validation, encoding and split: `$pang-survml-data`
- Univariable/multivariable Cox: `$pang-survml-cox-screen`
- Nomogram: `$pang-survml-nomogram`
- LASSO screening and paths: `$pang-survml-lasso`
- Models: `$pang-survml-rsf`, `$pang-survml-gbm`, `$pang-survml-coxph`, `$pang-survml-lasso-cox`, `$pang-survml-coxboost`, `$pang-survml-survivalsvm`, `$pang-survml-xgboost`, `$pang-survml-superpc`, `$pang-survml-plsrcox`
- Prediction-table contract: `$pang-survml-predictions`
- Interpretation: `$pang-survml-shap`
- Discrimination: `$pang-survml-time-auc`, `$pang-survml-cindex`, `$pang-survml-roc`
- Calibration and clinical utility: `$pang-survml-calibration`, `$pang-survml-dca`
- Risk stratification: `$pang-survml-km`
- Patient-facing prototype: `$pang-survml-individual-predictor`
- RData/PDF/CSV integrity: `$pang-survml-artifact-audit`
- Final tables, figures and audit trail: `$pang-survml-report`

## Mandatory analysis order

Use: preflight -> split/resampling plan -> preprocessing fitted on development data -> feature/model tuning inside resampling -> locked predictions -> evaluation -> explanation -> reporting. Never select variables, tune cutoffs, recalibrate, or choose the best model on an external validation cohort.

## Source fidelity versus corrected analysis

Preserve source parameters in a clearly named `legacy_reproduction` configuration when exact reproduction is requested. Use corrected defaults for new analyses. Read `references/methodological-corrections.md`; do not silently copy the original zero-time replacement, ordinary binary ROC at censored horizons, validation-set median KM cutoffs, hard-coded paths, or model-object overwrites.

## Required deliverables

Produce data audit, configuration, split manifest, preprocessing recipe, fitted model objects, locked train/validation predictions, metrics with uncertainty, all requested figures in PDF and 300-dpi PNG, session information, warnings, and a source-to-output manifest. State whether validation is apparent, internal, temporal or external. Do not describe a model as clinically deployable without appropriate external validation and implementation review.
