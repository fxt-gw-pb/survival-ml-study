---
name: pang-survml-calibration
description: Assess fixed horizon-specific survival-risk calibration corresponding to main-script lines 818-895 and 18 calibration PDFs. Use for observed-versus-predicted curves, calibration intercept/slope, Brier score and validation of absolute risk.
---

# Calibration

Require absolute-risk columns named `<model>__risk__<horizon>`. Run `scripts/calibration_groups.R <prediction.csv> <output_dir> <horizons_csv> [groups]`. Estimate observed event probability with Kaplan-Meier within risk groups; never refit the model on external validation. Report calibration slope/intercept with appropriate methods and uncertainty when available.
