# Source mapping

The source fits a new `rms::cph` model on each score within each dataset and bootstraps calibration at 12/36/60, producing eight train and eight test files in the current code; the folder has nine each because of legacy Lasso-Cox. Re-fitting on the test cohort is not external validation. Revised work evaluates fixed absolute-risk predictions.
