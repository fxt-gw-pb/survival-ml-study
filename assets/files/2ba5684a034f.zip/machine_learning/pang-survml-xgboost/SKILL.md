---
name: pang-survml-xgboost
description: Train and predict XGBoost with the Cox objective corresponding to main-script lines 327-345. Use for boosted-tree survival ranking, censored-label encoding, validation-based early stopping and XGBoost SHAP.
---

# XGBoost Cox

Run `scripts/train_xgboost.R <development.csv> <validation.csv> <output_dir> [predictors_csv] [seed]`. Encode censored labels as negative time only after confirming XGBoost version semantics. Use inner development folds for early stopping; do not monitor the final external validation set or the training matrix itself. Lock feature columns.
