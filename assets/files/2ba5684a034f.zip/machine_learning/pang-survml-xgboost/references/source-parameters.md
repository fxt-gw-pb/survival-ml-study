# Source parameters

The source uses Cox objective, tree booster, Cox negative log-likelihood, eta .03, depth 3, full row/column sampling, gamma .5 and 100 rounds. It specifies the training matrix as the only watchlist while requesting early stopping, so the stopping estimate is optimistic. Revised code creates an inner development holdout.
