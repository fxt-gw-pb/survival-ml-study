# Source mapping

The source fits a one-score Cox model per algorithm and calls `riskRegression::Score` at 0–70 by five units, plotting a 0.7 reference. Existing AUC figures include eight legacy labels and no visible uncertainty ribbon. The revised script directly evaluates fixed score markers with IPCW and does not refit score mappings in validation.
