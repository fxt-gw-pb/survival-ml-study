---
name: pang-survml-time-auc
description: Compute and plot IPCW time-dependent AUC corresponding to main-script lines 655-747 and Train/Test_AUC.pdf. Use for discrimination over follow-up with censored outcomes and uncertainty.
---

# Time-dependent AUC

Run `scripts/time_auc.R <prediction.csv> <output_dir> <times_csv>`. Use only locked scores. Estimate AUC with censoring-aware IPCW, report uncertainty when supported, and restrict horizons to times with adequate at-risk/event information. Never substitute ordinary binary ROC that labels early censoring as survival.
