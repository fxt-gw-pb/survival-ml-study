---
name: pang-survml-rsf
description: Train, tune and predict a random survival forest corresponding to main-script lines 260-272. Use for nonlinear survival modeling, RSF risk scores, survival probabilities, variable importance or RSF inputs to downstream evaluation and SHAP.
---

# Random survival forest

Run `scripts/train_rsf.R <development.csv> <validation.csv> <output_dir> [predictors_csv] [seed]`. Read `references/source-parameters.md`.

Tune `mtry`, `nodesize` and tree count within development resampling; the script exposes source defaults only as starting values. Preserve the fitted forest, OOB diagnostics, variable importance, development predictions and locked validation predictions. Use mortality/risk ranking for discrimination and horizon-specific survival probabilities for calibration/DCA.
