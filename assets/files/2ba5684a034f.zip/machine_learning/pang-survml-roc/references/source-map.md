# Source mapping

The source creates a binary result at each horizon and applies pROC, including subjects censored before the horizon among controls. This is not censoring-aware. Existing files include test 12/36/60 and train 12/24/36/60, revealing a version mismatch with the current 12/36/60 loop.
