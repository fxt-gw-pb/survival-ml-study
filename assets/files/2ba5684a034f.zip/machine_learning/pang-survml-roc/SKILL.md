---
name: pang-survml-roc
description: Generate censoring-aware ROC curves at declared horizons corresponding to main-script lines 988-1190 and seven ROC PDFs. Use for 12/36/60-month or custom survival ROC, AUC and confidence intervals.
---

# Horizon ROC

Run `scripts/time_roc.R <prediction.csv> <output_dir> <times_csv>`. Use IPCW `timeROC` and locked scores. Export one curve and AUC table per horizon. Do not reproduce the legacy pROC recoding unless explicitly labeled as a biased legacy reproduction.
