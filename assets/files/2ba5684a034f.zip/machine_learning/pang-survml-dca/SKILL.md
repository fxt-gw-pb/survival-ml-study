---
name: pang-survml-dca
description: Perform survival decision-curve analysis corresponding to main-script lines 898-986 and six DCA PDFs. Use for net-benefit comparison at declared horizons when locked, calibrated absolute-risk predictions are available.
---

# Decision curve analysis

Require columns `<model>__risk__<horizon>` in [0,1]. Run `scripts/run_dca.R <prediction.csv> <output_dir> <horizons_csv>`. Use clinically defensible threshold ranges and show treat-all/treat-none. Do not convert arbitrary scores to probabilities by refitting on an external test set. Interpret net benefit only in the target population and horizon.
