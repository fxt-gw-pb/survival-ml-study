# Source mapping

The source computes 12/36/60-month DCA after converting each score through a Cox survival fit. Existing curves contain a legacy Lasso-Cox label in some files and CoxPH in others. Corrected validation requires probabilities derived entirely from the development model and baseline hazard, without test-cohort refitting.
