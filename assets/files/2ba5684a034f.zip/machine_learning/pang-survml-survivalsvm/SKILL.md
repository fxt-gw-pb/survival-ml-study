---
name: pang-survml-survivalsvm
description: Train and predict the Survival-SVM corresponding to main-script lines 311-322. Use for margin-based survival ranking, Survival-SVM risk scores, hyperparameter tuning and SHAP explanation.
---

# Survival-SVM

Run `scripts/train_survivalsvm.R <development.csv> <validation.csv> <output_dir> [predictors_csv] [seed]`. Tune kernel, gamma, margin and bound inside development resampling. Standardize continuous predictors using development estimates and preserve the recipe. Treat the output as a ranking score unless an explicit calibration model converts it to horizon risk.
