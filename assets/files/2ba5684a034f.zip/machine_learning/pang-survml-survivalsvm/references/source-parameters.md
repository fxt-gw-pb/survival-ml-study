# Source parameters

The source uses a linear kernel, `gamma.mu=.5`, quadratic programming, `makediff3`, margin .1 and bound 10. It does not tune these settings. Saved scores are on a distinct scale (about 21.6–53.3), so do not compare magnitude directly with other models.
