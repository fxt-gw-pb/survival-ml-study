---
name: survival-ml-km
description: "Create Kaplan-Meier curves and risk tables for survival-model risk strata while preserving validation integrity. Use when adapting train/test KM loops, deriving a training cut point, applying it unchanged to validation, or auditing high/low-risk survival plots from the Xiaopang survival ML v3 workflow."
---

# Survival ML Kaplan-Meier

Use risk-group KM curves as visualization, not the primary continuous-score performance metric.

## Procedure

1. Run `scripts/check_prediction_table.R PREDICTIONS.csv`.
2. Derive any median or alternative cut point from training predictions only.
3. Apply the unchanged training cut point and risk direction to validation data.
4. Plot survival curves, confidence intervals, risk tables, log-rank p values, and group counts.
5. Report the cut-point source and avoid selecting it to maximize separation.
6. Retain continuous-score AUC/C-index and calibration results alongside KM plots.

## Code

- Read `references/code-map.md` for the original eight-model loop.
- Adapt `assets/legacy-section.R`; correct the legacy behavior that recalculates medians separately in validation.
