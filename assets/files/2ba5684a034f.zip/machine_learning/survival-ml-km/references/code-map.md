# Code map

`assets/legacy-section.R` corresponds to original lines 1192 through the end.

The original code iterates over eight model score columns, constructs high/low groups, fits `survfit`, and exports `ggsurvplot` figures with confidence bands and risk tables.

Correct this validation issue: the original validation loop recomputes `median(predictor)` in the test set. Derive one cut point per model from training data and pass it unchanged to the validation loop.
