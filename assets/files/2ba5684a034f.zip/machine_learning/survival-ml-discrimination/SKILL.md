---
name: survival-ml-discrimination
description: "Evaluate survival-model discrimination with time-dependent AUC, C-index, and horizon-specific ROC/AUC confidence intervals. Use when validating Train_plot_data.csv/Test_plot_data.csv or adapting the AUC, C-index, and ROC sections of the Xiaopang survival ML v3 workflow."
---

# Survival ML Discrimination

Assess ranking performance without using validation data for model choice or cut-point tuning.

## Procedure

1. Run `scripts/check_prediction_table.R PREDICTIONS.csv`.
2. Confirm score direction, dataset role, follow-up unit, event coding, and requested horizons.
3. Restrict horizons to periods with adequate events and subjects at risk.
4. Report time-dependent AUC curves, horizon AUC with confidence intervals, and C-index with uncertainty.
5. Compare apparent training performance with untouched validation performance.
6. Do not infer calibration or clinical utility from AUC/C-index.
7. Export tidy metric tables in addition to figures.

## Code

- Read `references/code-map.md` for the `riskRegression::Score`, concordance, `timeROC`, and `pROC` mappings.
- Adapt `assets/legacy-section.R`, containing both original discrimination code segments.
