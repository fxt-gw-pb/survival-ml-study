# Code map

`assets/legacy-section.R` contains two source segments: original lines 658-817 and 992-1191.

- 658-748: train/test time-dependent AUC using `riskRegression::Score` and `plotAUC`.
- 749-817: train/test C-index.
- 992-1092: training ROC at selected horizons.
- 1093-1191: validation ROC.

Replace fixed `seq(0,70,5)` and hard-coded 12/24/36/60 horizons with prespecified values supported by follow-up. Preserve tidy metric tables and confidence intervals, not figures alone.
