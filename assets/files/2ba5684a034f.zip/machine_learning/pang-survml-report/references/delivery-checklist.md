# Delivery checklist

Require: frozen configuration; data dictionary; inclusion/exclusion flow; split manifest; missing-data and zero-time policy; preprocessing recipe; model/tuning parameters; package/session versions; prediction tables; AUC/C-index/ROC; calibration and Brier score; DCA; KM with development-derived cutoffs; SHAP target/background/nsim; all PDF/PNG figures; machine-readable tables; warnings and limitations; checksums and source-to-output manifest.
