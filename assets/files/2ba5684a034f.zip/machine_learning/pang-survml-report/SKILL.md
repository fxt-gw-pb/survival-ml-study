---
name: pang-survml-report
description: Assemble the final reproducible survival-ML delivery package from all Pang modules. Use for publication-ready tables/figures, model-comparison summaries, methods/results text, manifests and final technical audit.
---

# Final reporting

Run `scripts/build_manifest.R <analysis_dir> <output_csv>`. Include cohort flow, data audit, model settings, validation type, discrimination with uncertainty, calibration, DCA, KM, SHAP target definitions and limitations. Link every reported number to a machine-readable result file and every figure to its source script/configuration.

Do not select a winner from point estimates alone. Consider calibration, uncertainty, clinical utility, stability, transportability and complexity. State that retrospective/internal results do not establish clinical deployment readiness.
