# Version discrepancy

The current script uses CoxPH as model 3. Existing calibration, KM, ROC, DCA, SHAP and RData artifacts instead contain `Lasso_Cox` in multiple places. The first RData includes class `coxph` object `Lasso_Cox`; the second contains Lasso SHAP PDFs but no current training block. Treat this as a legacy branch, not as equivalent to CoxPH.
