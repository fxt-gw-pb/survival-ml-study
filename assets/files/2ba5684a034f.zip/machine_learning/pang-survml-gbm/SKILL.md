---
name: pang-survml-gbm
description: Train and predict a Cox gradient-boosting model corresponding to main-script lines 274-283. Use for GBM survival risk scores, tuned boosting, downstream evaluation or model-specific SHAP.
---

# Survival GBM

Run `scripts/train_gbm.R <development.csv> <validation.csv> <output_dir> [predictors_csv] [seed]`. Tune tree count, depth, shrinkage and minimum node size inside development resampling. Save the selected iteration and use it consistently for prediction and SHAP. Read `references/source-parameters.md`.
