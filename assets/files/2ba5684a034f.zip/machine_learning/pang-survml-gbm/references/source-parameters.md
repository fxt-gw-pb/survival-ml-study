# Source parameters

The legacy model uses 1,000 trees, depth 5, minimum node size 3, shrinkage 0.01, ten-fold CV and six cores, but predicts at tree 1,000 rather than selecting the CV optimum. Scores are link-scale values. The revised script selects the CV iteration and stores it with the model.
