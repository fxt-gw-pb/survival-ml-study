# Source mapping

The source changes `Time<=0` to `0.003`, fits `glmnet`/`cv.glmnet`, selects nonzero coefficients at `lambda.min`, and writes `lasso.fit.plot.pdf` plus `cvlasso.plot.pdf`. Its saved run selected the same eight manually chosen variables. The legacy code uses an oversized concatenated palette and does not export fold assignments; the revised script keeps the model matrix and reports `lambda.1se` as a more parsimonious alternative.
