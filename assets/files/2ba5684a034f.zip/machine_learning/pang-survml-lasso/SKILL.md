---
name: pang-survml-lasso
description: Perform LASSO-Cox feature selection and generate coefficient-path and cross-validation figures corresponding to main-script lines 129-257. Use for penalized survival feature screening with leakage-safe resampling and explicit lambda choice.
---

# LASSO-Cox selection

Run `scripts/lasso_select.R <development.csv> <output_dir> [predictors_csv] [seed]`. Read `references/source-map.md`.

Build the model matrix with saved contrasts, resolve zero times before invocation, and perform cross-validation only in development data. Report both `lambda.min` and `lambda.1se`; do not automatically treat selected features as confirmed causal prognostic factors. Export coefficients, selected terms, plots, model matrix schema and fitted objects.
