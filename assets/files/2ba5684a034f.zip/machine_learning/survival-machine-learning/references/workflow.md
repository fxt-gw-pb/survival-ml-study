# Workflow

## 1. Preflight and design

1. Preserve the raw CSV and record its checksum.
2. Run the preflight script.
3. Declare outcome definition, time origin, censoring mechanism, follow-up unit, target population, prediction horizons, and intended use.
4. Decide whether the task is model development, temporal validation, geographic validation, or external validation.
5. Prefer a prespecified independent split. If randomly splitting one cohort, stratify on event status and document the seed and ratio.

## 2. Preprocessing

1. Fit imputation, transformation, scaling, encoding, and feature filtering on training data only.
2. Preserve a preprocessing recipe and apply it unchanged to validation data.
3. Check nonlinear continuous effects; avoid arbitrary categorization solely for convenience.
4. Check rare factor levels and ensure train/test design matrices match.

## 3. Feature selection

The legacy workflow performs univariable/multivariable Cox screening followed by LASSO. This can be used for exploratory replication, but screening and LASSO must occur inside resampling for unbiased performance estimation.

- Define `sigvar` from the study protocol or a reproducible selection result.
- Use `rid` only when the LASSO design matrix and downstream learners share identical encoded columns.
- Do not select predictors using the validation set.

## 4. Model fitting

Fit the requested subset of models rather than assuming all eight are appropriate. Tune hyperparameters with inner resampling and evaluate with untouched validation predictions. Preserve risk-score orientation so higher values consistently mean higher risk.

The original script uses seed 123, a 70/30 split, 1,000 RSF trees, 1,000 GBM trees, and fixed learner settings. Treat these as replication defaults, not optimal universal values.

## 5. Prediction contract

Create one training and one validation table with:

`Time`, `Event`, and one numeric risk-score column per model.

Use stable model names: `Coxph`, `CoxBoost`, `RSF`, `GBM`, `Survivalsvm`, `xgboost`, `superpc`, `plsRcox`. Add `Lasso_Cox` or other models only when their fitting and prediction provenance is explicit.

## 6. Evaluation

- Discrimination: time-dependent AUC curves, horizon-specific ROC/AUC with confidence intervals, and C-index with uncertainty.
- Calibration: observed versus predicted risk at clinically meaningful horizons; show intercept/slope when available.
- Clinical utility: DCA with justified threshold range and correctly defined event risk.
- Risk visualization: KM curves may display prespecified or training-derived strata, but do not substitute for continuous-score evaluation.
- Explainability: generate SHAP plots on a clearly identified dataset and state the prediction scale.

## 7. Validation checks

- Confirm risk direction is identical across models and plots.
- Confirm all horizons use the declared time unit.
- Confirm validation predictions were produced without refitting or retuning.
- Compare train and validation metrics for optimism.
- Inspect calibration and DCA, not AUC alone.
- Save `sessionInfo()`, seeds, model objects, prediction tables, configuration, and a run log.

## 8. Resume logic

If `Train_plot_data.csv` and `Test_plot_data.csv` exist, validate their row counts, `Time`/`Event`, model columns, missingness, finite values, and provenance before reusing them. If fitted `.RData` objects exist, load them only in an isolated R session and verify object names and package versions.
