# Legacy v3 source audit

## Preserved provenance

The complete source script is stored as `assets/original/pipeline-v3.R`. The original usage and CoxBoost notes are stored beside it. Keep these files unchanged for provenance; create working copies for every analysis.

## Hard-coded assumptions requiring adaptation

- Windows `setwd()` points to the author's local directory.
- Input must be named `data.csv`; the script reads it with GBK encoding.
- The first two columns are repeatedly assumed to be `Time` and `Event`.
- Example-specific factor mappings are embedded for oncology variables.
- A 70/30 event-stratified split and seed 123 are fixed.
- `sigvar` is manually fixed to eight example variables.
- Nomogram failure times are `1, 3, 5`, while other evaluations use month-scale horizons such as `12, 36, 60`; reconcile units before running.
- Some time-dependent AUC code uses a fixed sequence through 70.
- RSF/GBM/SVM/XGBoost/SuperPC/plsRcox hyperparameters are examples, not fully nested tuned settings.
- SHAP simulation count is fixed at 100 and several plots focus on survival-SVM.
- Median risk splits are learned separately in train and test in the legacy KM section; for validation, derive any threshold in training and apply it unchanged to test.

## Reproducibility and statistical hazards

- Running feature screening and LASSO before resampling can produce optimistic performance.
- A single random split can be unstable.
- Model objects are later overwritten by univariable Cox wrappers for AUC calculations; preserve original learner objects under distinct names.
- Large `.RData` files are opaque and package-version dependent; save explicit named objects and session metadata where possible.
- Existing result folders contain `Lasso_Cox` artifacts not consistently represented in the visible eight-model fitting block. Verify their provenance before reuse.
- DCA, calibration, and ROC horizons must not exceed support in the event/follow-up distribution.
- The source does not establish readiness for clinical deployment.

## Copyright and attribution

Treat the bundled source as user-supplied material for personal/local use. Preserve its original attribution comments. Do not redistribute the script or third-party package sources without appropriate permission.
