# Models and outputs

## Model map

| Stable name | Learner | Primary R package | Legacy prediction scale |
| --- | --- | --- | --- |
| `Coxph` | Cox proportional hazards | `survival` | Relative risk |
| `CoxBoost` | Boosted Cox model | `CoxBoost` | Linear predictor |
| `RSF` | Random survival forest | `randomForestSRC` | Ensemble mortality/risk |
| `GBM` | Cox gradient boosting | `gbm` | Link score |
| `Survivalsvm` | Survival support-vector machine | `survivalsvm` | Predicted ranking score |
| `xgboost` | Cox-optimized boosted trees | `xgboost` | Cox risk score |
| `superpc` | Supervised principal components | `superpc` | Component prediction score |
| `plsRcox` | Partial least-squares Cox | `plsRcox` | Risk score |

Always verify that a larger score represents worse prognosis before combining metrics or defining risk groups.

## R dependencies observed in v3

Core/modeling: `survival`, `survminer`, `glmnet`, `randomForestSRC`, `CoxBoost`, `survivalsvm`, `caret`, `gbm`, `riskRegression`, `pec`, `timeROC`, `pROC`, `survcomp`, `xgboost`, `superpc`, `plsRcox`, `rms`, `autoReg`, `regplot`.

Evaluation/graphics/explanation: `dcurves`, `ggDCA`, `survex`, `ModelMetrics`, `plotROC`, `fastshap`, `shapviz`, `gridExtra`, `ggplot2`, `dplyr`, `tidyr`, `ggsci`, `reshape`.

Install packages only with user authorization. Prefer CRAN/Bioconductor sources and record exact versions. Treat bundled third-party installation notes as historical guidance.

## Output inventory

The legacy workflow creates:

- `traindata.csv`, `testdata.csv`
- `训练集单因素多因素Cox回归.csv`
- `lasso.fit.plot.pdf`, `cvlasso.plot.pdf`, `Nomogram.pdf`
- `Train_plot_data.csv`, `Test_plot_data.csv`
- `Survival_ML_model.RData`, `Survival_ML_model_SHAP.RData`
- `AUC_Result/`: train/test time-dependent AUC and C-index
- `ROC_Result/`: train/test ROC at selected horizons
- `Calibrate_Result/`: model-specific train/test calibration plots
- `DCA_Result/`: train/test decision curves
- `KM_Result/`: train/test high-versus-low risk survival plots
- `SHAP_Result/`: force, beeswarm, bar, waterfall, and dependence plots

Keep a manifest that maps every artifact to dataset, horizon, model version, preprocessing version, and creation time.

## Recommended reporting

For each model and dataset, report sample size, number of events, horizon, AUC with confidence interval, C-index with confidence interval, calibration evidence, and DCA range. Explicitly label development/internal validation versus external validation. Report missing-data handling, tuning, resampling, and predictor selection.
