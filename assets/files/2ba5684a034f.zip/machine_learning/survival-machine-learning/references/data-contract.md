# Data contract

## Required columns

| Column | Type | Rule |
| --- | --- | --- |
| `Time` | numeric | Follow-up time in one declared unit; strictly positive for fitted analyses. |
| `Event` | integer/numeric | `1` for observed event and `0` for censoring. |

Place predictors after `Time` and `Event`. The legacy script assumes this order repeatedly, although adapted code should select columns by name.

## Predictor rules

- Supply a data dictionary with variable label, unit, type, valid range, missing-value codes, and reference category.
- Keep continuous predictors numeric unless a prespecified clinical threshold justifies categorization.
- Convert categorical predictors with explicit levels and labels. Never reuse the example mappings for Age, Race, Gender, Grade, Surgery, treatment, stage, fibrosis, tumor size, or income unless the new dataset uses exactly those codes.
- One-hot encode factors for matrix-only learners using a training-fitted design matrix and apply identical columns to validation data.
- Remove identifiers, post-outcome variables, future information, and derived variables that leak the endpoint.

## Minimum audit

Run:

```powershell
Rscript scripts/preflight_survival_ml.R path/to/data.csv
```

Review row count, event count/rate, follow-up distribution, missingness, zero-variance predictors, nonnumeric predictors, and candidate horizons. A structurally valid dataset is not automatically adequate for modeling.

## Sample-size considerations

- Compare the number of observed events with effective model degrees of freedom, not only total sample size.
- Reduce model complexity or use penalization when events are sparse.
- Ensure each evaluation horizon has adequate subjects at risk and enough preceding events.
- Use resampling that repeats all preprocessing and selection steps.

## Existing example

`assets/original/example-data.csv` contains 2,038 rows and these columns:

`Time, Event, Age, Race, Gender, Grade, Surgery, Radiotherapy, Chemotherapy, Marital, AJCC_stage, T_stage, N_stage, M_stage, SEER_stage, Fibrosis_score, Tumor_size, Income`.

Treat it as a format example, not a universal schema.
