---
name: survival-machine-learning
description: "R-based survival machine-learning workflow for censored time-to-event data. Use when Codex needs to audit or adapt the Xiaopang Statistics survival ML v3 pipeline; validate Time/Event datasets; split train/test cohorts; fit or compare CoxPH, RSF, GBM, CoxBoost, survival-SVM, XGBoost-Cox, SuperPC, or plsRcox models; perform Cox/LASSO selection; generate nomograms, time-dependent AUC/C-index, ROC, calibration, DCA, Kaplan-Meier, or SHAP outputs; or diagnose the pipeline's R dependencies and hard-coded assumptions."
---

# Survival Machine Learning

Use this skill to convert a clean censored survival dataset into an audited, reproducible model-development and validation workflow based on the bundled v3 R pipeline.

## Core workflow

1. Locate the input CSV and a writable analysis directory. Preserve the source file.
2. Read [references/data-contract.md](references/data-contract.md). Run `scripts/preflight_survival_ml.R` before modeling.
3. Stop for critical failures: missing `Time`/`Event`, nonnumeric survival fields, event codes outside 0/1, nonpositive times, duplicated IDs when an ID exists, or data leakage.
4. Read [references/workflow.md](references/workflow.md). Define the prediction horizon, estimand, split/resampling plan, candidate predictors, factor encoding, missing-data strategy, feature-selection scope, and evaluation metrics before fitting.
5. Copy `assets/original/pipeline-v3.R` into the analysis directory. Never edit the bundled original in place.
6. Replace its hard-coded `setwd()`, example-specific factor conversions, `sigvar`, time points, and tuning parameters. Run stages incrementally; do not source the entire legacy script blindly.
7. Fit only models supported by the data size, event count, predictor types, and installed packages. Keep preprocessing and feature selection inside resampling when estimating generalization performance.
8. Export model predictions and evaluation artifacts using the contract in [references/models-and-outputs.md](references/models-and-outputs.md).
9. Audit discrimination, calibration, clinical utility, overfitting, proportional-hazards assumptions where applicable, and train/test consistency. Treat SHAP values as model explanations, not causal effects.
10. Record seeds, package versions, preprocessing, exclusions, horizons, tuning, and all deviations from the legacy script.

## Execution modes

- **Audit only:** inspect data, packages, source assumptions, and existing outputs without refitting.
- **Adapt:** prepare a project-specific copy of the legacy pipeline and specify required edits.
- **Run:** execute the configured stages, verify outputs after each stage, and stop on invalid metrics or leakage.
- **Resume:** locate completed prediction CSV/RData files, validate their columns and provenance, then continue only missing evaluation stages.

## Module routing

Use the smallest matching module; use this skill as the end-to-end controller.

| Stage | Skill |
| --- | --- |
| R environment and dependencies | `$survival-ml-setup` |
| Data audit, encoding, split | `$survival-ml-data` |
| Cox/LASSO selection and nomogram preparation | `$survival-ml-select` |
| Eight-model fitting and risk-score export | `$survival-ml-train` |
| SHAP explanation | `$survival-ml-shap` |
| Time-dependent AUC, C-index, ROC | `$survival-ml-discrimination` |
| Calibration and DCA | `$survival-ml-calibration-dca` |
| Kaplan-Meier risk groups | `$survival-ml-km` |

## Guardrails

- Do not infer factor labels from numeric codes. Require a data dictionary or explicit user mapping.
- Do not use test data for imputation fitting, feature selection, tuning, cut-point selection, or model choice.
- Do not report apparent/training performance as external validation.
- Do not use a median risk split as the primary assessment of a continuous prognostic score; keep it as a visualization only.
- Do not compare models at horizons beyond adequate event follow-up.
- Prefer repeated cross-validation or bootstrap optimism correction when no independent validation cohort exists.
- Report uncertainty for AUC/C-index/calibration and acknowledge multiple model comparisons.
- Do not present the resulting model as ready for clinical deployment without independent validation, transportability assessment, and impact evaluation.

## Bundled resources

- `scripts/preflight_survival_ml.R`: dependency-free structural and statistical input audit.
- `references/data-contract.md`: input schema and encoding rules.
- `references/workflow.md`: stage-by-stage adaptation and analysis procedure.
- `references/models-and-outputs.md`: eight-model map, dependencies, predictions, and result inventory.
- `references/source-audit.md`: legacy v3 assumptions, hazards, and known adaptation points.
- `assets/original/`: preserved original R script, example data, usage note, and CoxBoost installation notes.

Keep generated datasets, fitted models, and figures in the user's analysis directory, not inside this skill.
