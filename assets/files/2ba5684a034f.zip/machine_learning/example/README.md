# 生存机器学习skill样本图

本目录包含8张合成数据样本图，用于展示skill最终可生成的主要结果。所有数值均为演示数据，不代表真实临床研究。

- `00_example_gallery.png`：8图总览。
- `figures/`：每张图的300 dpi独立PNG。
- `figure_manifest.csv`：图型清单。
- `generate_examples.R`：可复现生成脚本。
