# Source mapping

Main-script lines 106-120 fit `coxph` and call `regplot` with density/box panels and `failtime=c(1,3,5)`. Lines 122-126 create train/test risk scores. `Nomogram.pdf` is A4 landscape. The SHAP RData retains `nom1`, `res.cox`, `Nomo_train` and `Nomo_test`. Treat the 1/3/5 horizon call as unit-ambiguous because the usage file declares months.
