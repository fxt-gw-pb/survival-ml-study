---
name: pang-survml-nomogram
description: Fit and render the Cox nomogram and derive nomogram risk scores corresponding to main-script lines 106-128. Use for prespecified Cox prediction at declared survival horizons, not for replacing model validation.
---

# Nomogram

Run `scripts/fit_nomogram.R <development.csv> <validation.csv> <output_dir> <horizons_csv> <predictors_csv>`. Horizons must use the same unit as `Time`; for monthly data the source intent is `12,36,60`, not its literal `1,3,5` call.

Fit only in development data, store the Cox object and fixed linear predictors for both cohorts, and verify proportional hazards. Render the nomogram only after validation settings are fixed. Read `references/source-map.md`.
