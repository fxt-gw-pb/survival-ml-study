---
name: pang-survml-artifact-audit
description: Inspect RData, CSV, PDF and model-output integrity for the Pang suite. Use when checking saved objects, stale workspaces, output/model label mismatches, missing figures, dimensions, hashes or reproducibility before delivery.
---

# Artifact audit

Run `scripts/audit_artifacts.R <project_dir> <output_dir>`. Load each RData into an isolated environment; never into `.GlobalEnv`. Inventory names, classes, dimensions and sizes. Validate CSV schemas and PDF readability/page count. Compare model labels across predictions, figures and saved objects. Read `references/known-findings.md` and update findings from the actual run.
