# Known findings in the audited source snapshot

- Two RData workspaces hold 62 and 119 objects; loading emits missing-namespace warnings for plsRcox, randomForestSRC, xgboost and shiny in the current environment.
- Whole-workspace files contain large RSF objects, intermediate data, tuning results and overwritten names; use named RDS files instead.
- `Survival_ML_model.RData` contains `Lasso_Cox`, while the current script trains `Coxph`.
- The SHAP workspace contains Shiny `ui/server` and baseline-survival objects absent from the current script.
- All 77 PDFs are readable, one page each. Categories: 4 AUC/C-index, 18 calibration, 6 DCA, 16 KM, 7 ROC, 23 SHAP, 2 LASSO and 1 nomogram.
- The source CSV contains 65 zero-time rows. Original prediction tables contain no missing scores but no patient IDs.
