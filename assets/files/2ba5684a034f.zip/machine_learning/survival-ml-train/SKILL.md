---
name: survival-ml-train
description: "Train and compare CoxPH, random survival forest, GBM-Cox, CoxBoost, survival-SVM, XGBoost-Cox, SuperPC, and plsRcox models, then export consistent train/test risk scores. Use when executing or adapting the eight-model training block of the Xiaopang survival ML v3 workflow."
---

# Survival ML Training

Fit requested learners with training-only tuning and consistent prediction contracts.

## Procedure

1. Require completed data and predictor-selection handoffs.
2. Run `scripts/check_training_dependencies.R` and report missing packages without installing them automatically.
3. Preserve original learner objects under unique names; do not overwrite them with evaluation Cox wrappers.
4. Tune each learner inside inner resampling. Treat legacy hyperparameters as replication examples.
5. Apply identical encoded predictor columns to validation data.
6. Verify risk direction: larger score must consistently represent worse prognosis or be explicitly reversed.
7. Export `Train_plot_data.csv` and `Test_plot_data.csv` with `Time`, `Event`, and stable model columns.
8. Save named model objects, preprocessing, tuning results, seed, and `sessionInfo()`.

## Code

- Read `references/code-map.md` for model-by-model inputs, packages, and predictions.
- Adapt `assets/legacy-section.R`, which contains the complete original eight-model fitting and score-export block.
- Hand off predictions to `$survival-ml-shap`, `$survival-ml-discrimination`, `$survival-ml-calibration-dca`, and `$survival-ml-km`.
