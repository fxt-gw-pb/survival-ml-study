# Code map

`assets/legacy-section.R` corresponds to original lines 258-408.

| Lines | Model |
| --- | --- |
| 260-273 | RSF (`randomForestSRC`) |
| 274-287 | GBM-Cox (`gbm`) |
| 288-294 | CoxPH (`survival`) |
| 295-310 | CoxBoost |
| 311-326 | survival-SVM |
| 327-347 | XGBoost-Cox |
| 348-367 | SuperPC |
| 368-376 | plsRcox |
| 381-408 | Merge and export train/test scores |

Do not accept the fixed hyperparameters as tuned defaults. Keep learners under names such as `fit_rsf` and `fit_gbm`; later legacy code reuses model names for evaluation wrappers.
