---
name: pang-survml-predictions
description: Assemble and validate locked development/validation prediction tables corresponding to main-script lines 381-401 and Train/Test_plot_data.csv. Use before any AUC, C-index, ROC, calibration, DCA, KM or SHAP comparison.
---

# Prediction contract

Run `scripts/validate_predictions.R <prediction.csv> <output_report.csv>`. Require `Time`, `Event`, and one or more numeric score or horizon-risk columns. Join by stable ID when available; never use row order across independently transformed files.

Use plain model names for monotonic risk scores. Name absolute-risk columns `<model>__risk__<horizon>` and constrain them to [0,1]. Record whether higher values mean higher event risk. Reject missing, infinite, constant or duplicated model columns.
