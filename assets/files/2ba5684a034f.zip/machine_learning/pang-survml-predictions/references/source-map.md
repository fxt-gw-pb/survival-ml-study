# Source mapping

The source concatenates eight model scores into `Train_plot_data.csv` and `Test_plot_data.csv`, each with ten columns. It relies on row order and has no patient ID. Existing tables contain 1,427 and 611 rows with no missing predictions, but model score scales differ substantially. Preserve scores without normalization for rank metrics; use separately calibrated horizon probabilities for calibration and DCA.
