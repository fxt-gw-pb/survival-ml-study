---
name: pang-survml-environment
description: Audit and prepare the R environment for the Pang survival ML suite, including CRAN/Bioconductor/GitHub dependencies and the bundled CoxBoost source. Use before running any source-derived pipeline, when packages fail to load, or when reproducing the original Windows setup.
---

# Environment and dependencies

Run `scripts/check_packages.R <output.csv>` first. Report installed and missing packages without installing anything unless the user authorizes installation.

Read `references/package-map.md`. Prefer current repositories and record package versions. Treat the bundled CoxBoost archive as a historical fallback: inspect its DESCRIPTION and source, then install into a project library only if a compatible repository build is unavailable. Never retain the legacy hard-coded desktop `setwd()`.

After installation, rerun the checker and save `sessionInfo()`. Distinguish required packages for the requested module from optional packages for unrelated modules.
