# Package provenance

Source main-script lines 12-45 load 28 packages, with duplicates for `survival`, `randomForestSRC` and `rms`. Later sections also require `regplot`, `reshape`, `fastshap`, `shapviz`, `gridExtra` and `scales`.

- Core survival/Cox: `survival`, `rms`, `autoReg`, `regplot`, `survminer`.
- Selection/models: `glmnet`, `randomForestSRC`, `gbm`, `CoxBoost`, `survivalsvm`, `xgboost`, `superpc`, `plsRcox`.
- Evaluation: `riskRegression`, `pec`, `timeROC`, `pROC`, `survcomp`, `dcurves`, `ggDCA`.
- Explainability/graphics: `fastshap`, `shapviz`, `survex`, `ggplot2`, `ggsci`, `gridExtra`.

Bundled files include `distr6_1.6.9.tar.gz`, `CoxBoost-master.zip`, the unpacked CoxBoost package with five R files, two C files and fifteen Rd manuals, and a legacy installer that builds from a fixed desktop path. Do not copy that path; install from an explicit local archive or source directory after compatibility review.
