---
name: pang-survml-cox-screen
description: Run audited univariable and multivariable Cox screening corresponding to main-script lines 88-105. Use for hazard-ratio tables, prespecified Cox adjustment, candidate-variable screening or proportional-hazards diagnostics before prediction modeling.
---

# Cox screening

Run `scripts/cox_screen.R <development.csv> <output_dir> [predictor1,predictor2,...]`. Prefer clinically prespecified variables. If univariable p-value screening is requested, label it exploratory and do not leak validation outcomes into selection.

Check convergence, sparse levels, nonlinearity and `cox.zph`. Preserve reference levels and write coefficient/HR/CI/p-value tables plus diagnostics. Read `references/source-result.md` before reproducing the source table.
