---
name: pang-survml-coxph
description: Fit and validate the multivariable Cox proportional-hazards prediction model corresponding to main-script lines 288-291. Use for Cox risk scores, baseline survival, horizon probabilities, PH diagnostics and a transparent benchmark model.
---

# CoxPH model

Run `scripts/train_coxph.R <development.csv> <validation.csv> <output_dir> [predictors_csv]`. Inspect `ph_test.csv` and influence/convergence warnings. Keep factor levels fixed and consider nonlinear terms where appropriate. Use the locked development baseline survival for validation probabilities.
