# Source parameters

The current script fits all selected variables with `coxph` and exports `type='risk'`. The saved SHAP workspace contains a CoxPH model on the same eight predictors. Use linear predictor for interpretable score work and convert to absolute risk only through the development baseline survival.
