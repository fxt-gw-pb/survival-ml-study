# Source mapping

The source creates eight train and eight test KM PDFs. It correctly uses a median within train, but recomputes a separate median within test, changing the decision rule. Existing test Survival-SVM separation is weak (`p≈0.053`) while most others show strong separation; this illustrates why dichotomized apparent separation is not a substitute for calibrated validation.
