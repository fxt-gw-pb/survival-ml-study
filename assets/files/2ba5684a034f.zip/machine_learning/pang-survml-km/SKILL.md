---
name: pang-survml-km
description: Generate risk-stratified Kaplan-Meier curves corresponding to main-script lines 1193-1283 and 16 KM PDFs. Use for development-derived risk groups, log-rank summaries, confidence bands and risk tables in development and validation cohorts.
---

# KM risk groups

Run `scripts/km_by_locked_cutoff.R <development_predictions.csv> <validation_predictions.csv> <output_dir>`. Derive each median cutoff from development data and apply it unchanged to validation. Export cutoff values, group counts, log-rank tests and plots. Label dichotomization as descriptive and retain continuous-score metrics as primary.
