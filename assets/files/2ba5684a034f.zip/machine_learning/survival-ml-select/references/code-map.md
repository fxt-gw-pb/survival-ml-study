# Code map

`assets/legacy-section.R` corresponds to original lines 130-257.

- Lines 130-150: reread numeric data and build the Cox-LASSO matrix.
- Lines 151-212: coefficient-path plotting.
- Lines 213-249: cross-validation deviance plotting.
- Lines 250-257: choose `sigvar` versus `rid` for model inputs.

Required edits: move all preprocessing/selection inside resampling, use explicit named columns, preserve `lambda.min` and `lambda.1se`, and reconcile nomogram times with the dataset unit.
