---
name: survival-ml-select
description: "Perform leakage-aware survival predictor selection with Cox screening, multivariable Cox, LASSO-Cox, and nomogram preparation. Use when adapting the sigvar/rid sections of the Xiaopang survival ML v3 code, checking selection stability, or preparing a final predictor set for downstream survival learners."
---

# Survival ML Selection

Select predictors using training data only and preserve selection provenance.

## Procedure

1. Read `traindata.csv` from `$survival-ml-data` and verify `Time`, `Event`, and predictor columns.
2. Treat univariable Cox screening as exploratory; do not make it the sole inclusion rule.
3. Check proportional hazards, functional form, collinearity, sparse levels, and events relative to model complexity.
4. Run LASSO-Cox inside resampling when estimating performance. Record `lambda.min`, `lambda.1se`, folds, seed, and selected columns.
5. Keep a prespecified clinical set when appropriate; distinguish it from data-driven `sigvar`/`rid`.
6. Build a nomogram only after finalizing a supported Cox model and reconciling time units.
7. Export selected-variable lists and selection plots; hand off to `$survival-ml-train`.

## Code

- Run `scripts/check_selection_inputs.R TRAIN.csv` before fitting.
- Read `references/code-map.md` for line-by-line adaptation points.
- Adapt a copy of `assets/legacy-section.R`; never edit the asset.
