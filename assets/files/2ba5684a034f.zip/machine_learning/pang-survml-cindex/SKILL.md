---
name: pang-survml-cindex
description: Compute global and time-dependent concordance corresponding to main-script lines 751-814 and Train/Test_C_index.pdf. Use for censored ranking performance, model comparison and concordance uncertainty.
---

# Concordance

Run `scripts/cindex.R <development_predictions.csv> <validation_predictions.csv> <output_dir> <times_csv>`. Fit any required score adapter only in development data, then evaluate fixed mappings in validation. Report global Harrell concordance and time-dependent concordance separately; include uncertainty and comparable horizons.
