# 生存机器学习 3.0 全量 Skill 索引

新版权威入口为 `pang-survml`。所有 `pang-survml-*` 均按 `skill-creator` 模板建立，包含 `SKILL.md`、`agents/openai.yaml`、可执行 R 脚本和源映射参考。旧的 `survival-ml-*` 文件夹保留作历史版本，不作为本次全面重构的权威实现。

| Skill | 对应内容 | 可执行脚本 |
|---|---|---|
| `pang-survml` | 总控、数据契约、方法学修正、模块路由 | `preflight.R` |
| `pang-survml-environment` | 主脚本包依赖、CoxBoost 源码、distr6 包 | `check_packages.R` |
| `pang-survml-source-audit` | 121 文件和 RData 对象全量盘点 | `inventory_source.R` |
| `pang-survml-data` | Time/Event、编码、零时间、分层划分 | `prepare_split.R` |
| `pang-survml-cox-screen` | 单因素/多因素 Cox、PH 检验 | `cox_screen.R` |
| `pang-survml-nomogram` | 列线图和风险评分 | `fit_nomogram.R` |
| `pang-survml-lasso` | LASSO 选择、系数路径、CV 曲线 | `lasso_select.R` |
| `pang-survml-rsf` | 随机生存森林 | `train_rsf.R` |
| `pang-survml-gbm` | Cox GBM | `train_gbm.R` |
| `pang-survml-coxph` | CoxPH 基准模型 | `train_coxph.R` |
| `pang-survml-lasso-cox` | 成品/RData 中的遗留 Lasso-Cox | `train_lasso_cox.R` |
| `pang-survml-coxboost` | CoxBoost 和本地源码安装逻辑 | `train_coxboost.R` |
| `pang-survml-survivalsvm` | Survival-SVM | `train_survivalsvm.R` |
| `pang-survml-xgboost` | XGBoost Cox 与正确早停 | `train_xgboost.R` |
| `pang-survml-superpc` | SuperPC | `train_superpc.R` |
| `pang-survml-plsrcox` | PLS-R Cox | `train_plsrcox.R` |
| `pang-survml-predictions` | 统一预测表和绝对风险命名契约 | `validate_predictions.R` |
| `pang-survml-shap` | 7 类现有 SHAP 图及模型包装器 | `explain_score.R` |
| `pang-survml-time-auc` | IPCW 时间依赖 AUC | `time_auc.R` |
| `pang-survml-cindex` | 全局/时间依赖 C-index | `cindex.R` |
| `pang-survml-roc` | IPCW 指定时点 ROC | `time_roc.R` |
| `pang-survml-calibration` | 固定预测的校准图 | `calibration_groups.R` |
| `pang-survml-dca` | 12/36/60 月 DCA | `run_dca.R` |
| `pang-survml-km` | 训练集阈值锁定的 KM 曲线 | `km_by_locked_cutoff.R` |
| `pang-survml-individual-predictor` | RData 中隐藏的 PLS-R Cox Shiny 应用 | `build_app.R` |
| `pang-survml-artifact-audit` | RData/CSV/PDF/哈希一致性检查 | `audit_artifacts.R` |
| `pang-survml-report` | 最终交付物和校验清单 | `build_manifest.R` |

完整逐文件映射位于 `_validation/source_inventory/source_file_manifest.csv`；主脚本逐代码段映射位于 `_validation/source_inventory/main_script_line_map.csv`。77 个 PDF 的七张目视审计联系表位于 `_source_audit/pdf_renders/contact_01.png` 至 `contact_07.png`。
