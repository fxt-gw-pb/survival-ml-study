# Source parameters

The source performs ten-component, ten-fold CV but then hard-codes `nt=3`. The RData Shiny app uses the eight selected variables and derives 1–5 year survival from a saved baseline curve. Revised work must extract and record the selected component count and validate absolute-risk conversion.
