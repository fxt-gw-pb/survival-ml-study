---
name: pang-survml-plsrcox
description: Train, cross-validate and predict partial least-squares Cox regression corresponding to main-script lines 368-373. Use for PLS-R Cox component selection, risk scores, SHAP wrappers and the legacy individual-prediction app.
---

# PLS-R Cox

Run `scripts/train_plsrcox.R <development.csv> <validation.csv> <output_dir> [predictors_csv] [seed]`. Select the number of components from development CV and use that number in the final fit. Save the exact predictor order and development baseline survival for absolute-risk prediction.
