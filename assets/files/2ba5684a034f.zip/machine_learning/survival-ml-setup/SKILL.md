---
name: survival-ml-setup
description: "Audit and prepare the R runtime for the Xiaopang survival machine-learning v3 workflow. Use when checking required CRAN/Bioconductor/GitHub packages, diagnosing CoxBoost or survcomp installation, replacing hard-coded setwd paths, or recording reproducible package versions before survival modeling."
---

# Survival ML Setup

Prepare the runtime without silently changing the user's R installation.

## Procedure

1. Run `scripts/check_dependencies.R` and report installed/missing packages.
2. Ask for approval before installing any package or building CoxBoost source.
3. Prefer CRAN/Bioconductor packages; use GitHub/local source only when required and record provenance.
4. Remove the original hard-coded `setwd()` from working copies. Accept explicit input/output paths instead.
5. Record R version, platform, package versions, locale, and `sessionInfo()`.
6. Hand off to `$survival-ml-data` only after the required stage-specific packages are available.

## Code

- `assets/legacy-section.R` preserves original lines 1-47: attribution, package loads, and hard-coded path.
- `references/code-map.md` maps packages to workflow stages.
- `scripts/check_dependencies.R` performs a read-only package audit.
