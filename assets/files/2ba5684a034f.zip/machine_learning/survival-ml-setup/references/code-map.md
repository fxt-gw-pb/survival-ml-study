# Code map

`assets/legacy-section.R` corresponds to original lines 1-47.

| Stage | Packages |
| --- | --- |
| Data/splitting | `caret`, `dplyr`, `tidyr` |
| Cox/LASSO/nomogram | `survival`, `glmnet`, `autoReg`, `rms`, `regplot` |
| Eight models | `randomForestSRC`, `gbm`, `CoxBoost`, `survivalsvm`, `xgboost`, `superpc`, `plsRcox` |
| Discrimination | `riskRegression`, `pec`, `timeROC`, `pROC`, `survcomp`, `plotROC` |
| Calibration/DCA | `riskRegression`, `dcurves`, `ggDCA` |
| KM | `survival`, `survminer` |
| SHAP | `fastshap`, `shapviz`, `survex`, `gridExtra` |
| Graphics | `ggplot2`, `ggsci` |

Do not load every package for every stage. Load only the packages required by the invoked module.
